plugins {
    java
}

group = "de.anticheat"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // Paper 26.1+ benötigt Java 25. Das Plugin läuft auch auf neueren Versionen (z. B. 26.3).
    compileOnly("io.papermc.paper:paper-api:26.1.2.build.+")
}

tasks.withType<JavaCompile> {
    options.release.set(25)
    options.encoding = "UTF-8"
}

tasks.processResources {
    val props = mapOf("version" to project.version)
    inputs.properties(props)
    filteringCharset = "UTF-8"
    filesMatching("plugin.yml") {
        expand(props)
    }
}

tasks.jar {
    archiveBaseName.set("SimpleAntiCheat")
}
