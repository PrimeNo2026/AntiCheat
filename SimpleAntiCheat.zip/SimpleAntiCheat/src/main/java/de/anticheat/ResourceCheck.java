package de.anticheat;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Zählt abgebaute wertvolle Erze in einem gleitenden Zeitfenster. */
public final class ResourceCheck implements Check {

    private static final int MAX_TRACKED_PLACED_BLOCKS = 5000;

    private record Group(String id, String displayName, int max) {
    }

    private record BlockKey(UUID world, int x, int y, int z) {
        static BlockKey of(Block block) {
            return new BlockKey(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ());
        }
    }

    private final AntiCheatPlugin plugin;
    private final AlertManager alerts;
    private final Map<Material, Group> byMaterial = new HashMap<>();
    private final Map<UUID, Map<String, ArrayDeque<Long>>> history = new HashMap<>();
    /** Von Spielern platzierte Erze: Werden sie wieder abgebaut, zählen sie nicht (kein Farm-Fehlalarm). */
    private final Set<BlockKey> placedByPlayers = new LinkedHashSet<>();
    private boolean enabled;
    private long windowMs;

    public ResourceCheck(AntiCheatPlugin plugin, AlertManager alerts) {
        this.plugin = plugin;
        this.alerts = alerts;
    }

    @Override
    public void load(FileConfiguration config) {
        enabled = config.getBoolean("resource-check.enabled", true);
        windowMs = Math.max(1, config.getLong("resource-check.window-seconds", 300)) * 1000L;
        byMaterial.clear();
        history.clear();
        placedByPlayers.clear();

        ConfigurationSection groups = config.getConfigurationSection("resource-check.groups");
        if (groups == null) {
            return;
        }
        for (String id : groups.getKeys(false)) {
            ConfigurationSection section = groups.getConfigurationSection(id);
            if (section == null) {
                continue;
            }
            Group group = new Group(id, section.getString("name", id), Math.max(1, section.getInt("max", 10)));
            Set<Material> materials = new HashSet<>();
            for (String name : section.getStringList("materials")) {
                Material material = Material.matchMaterial(name);
                if (material == null) {
                    plugin.getLogger().warning("Unbekanntes Material in resource-check." + id + ": " + name);
                } else {
                    materials.add(material);
                }
            }
            for (Material material : materials) {
                byMaterial.put(material, group);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!enabled || !byMaterial.containsKey(event.getBlockPlaced().getType())) {
            return;
        }
        placedByPlayers.add(BlockKey.of(event.getBlockPlaced()));
        if (placedByPlayers.size() > MAX_TRACKED_PLACED_BLOCKS) {
            Iterator<BlockKey> oldest = placedByPlayers.iterator();
            oldest.next();
            oldest.remove();
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!enabled) {
            return;
        }
        Block block = event.getBlock();
        Group group = byMaterial.get(block.getType());
        if (group == null) {
            return;
        }
        // Selbst platzierte Erze ignorieren
        if (placedByPlayers.remove(BlockKey.of(block))) {
            return;
        }
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.hasPermission(AlertManager.PERM_BYPASS)) {
            return;
        }

        long now = System.currentTimeMillis();
        ArrayDeque<Long> times = history
                .computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
                .computeIfAbsent(group.id(), k -> new ArrayDeque<>());
        times.addLast(now);
        while (!times.isEmpty() && now - times.peekFirst() > windowMs) {
            times.pollFirst();
        }

        if (times.size() >= group.max()) {
            long seconds = (now - times.peekFirst()) / 1000L;
            alerts.alert("Ressourcen", player,
                    times.size() + "x " + group.displayName() + " in " + seconds
                            + "s abgebaut (Limit " + group.max() + ")",
                    true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        history.remove(event.getPlayer().getUniqueId());
    }
}
