package de.anticheat;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Verschickt Meldungen an alle Admins (Permission anticheat.alerts) und an die Konsole. */
public final class AlertManager {

    public static final String PERM_ALERTS = "anticheat.alerts";
    public static final String PERM_BYPASS = "anticheat.bypass";

    private final AntiCheatPlugin plugin;
    private final Set<UUID> muted = ConcurrentHashMap.newKeySet();
    private final Map<String, Long> lastAlert = new HashMap<>();
    private long cooldownMs = 10_000L;

    public AlertManager(AntiCheatPlugin plugin) {
        this.plugin = plugin;
    }

    public void load(FileConfiguration config) {
        cooldownMs = Math.max(0, config.getLong("alerts.cooldown-seconds", 10)) * 1000L;
    }

    public void alert(String category, Player suspect, String detail, boolean useCooldown) {
        long now = System.currentTimeMillis();

        if (useCooldown) {
            String key = suspect.getUniqueId() + ":" + category;
            Long last = lastAlert.get(key);
            if (last != null && now - last < cooldownMs) {
                return;
            }
            lastAlert.put(key, now);
            if (lastAlert.size() > 1000) {
                lastAlert.values().removeIf(t -> now - t > cooldownMs);
            }
        }

        Location loc = suspect.getLocation();
        String where = loc.getWorld().getName() + " " + loc.getBlockX() + " " + loc.getBlockY() + " " + loc.getBlockZ();

        Component message = Component.text()
                .append(Component.text("[AntiCheat] ", NamedTextColor.GOLD, TextDecoration.BOLD))
                .append(Component.text(category + " ", NamedTextColor.RED))
                .append(Component.text(suspect.getName(), NamedTextColor.YELLOW)
                        .clickEvent(ClickEvent.suggestCommand("/tp " + suspect.getName()))
                        .hoverEvent(HoverEvent.showText(
                                Component.text("Klicken: /tp " + suspect.getName(), NamedTextColor.GRAY))))
                .append(Component.text(" - " + detail, NamedTextColor.GRAY))
                .append(Component.text(" [" + where + "]", NamedTextColor.DARK_GRAY))
                .build();

        for (Player admin : Bukkit.getOnlinePlayers()) {
            if (admin.hasPermission(PERM_ALERTS) && !muted.contains(admin.getUniqueId())) {
                admin.sendMessage(message);
            }
        }
        plugin.getLogger().info("[" + category + "] " + suspect.getName() + " - " + detail + " [" + where + "]");
    }

    /** @return true, wenn die Meldungen für den Spieler danach eingeschaltet sind */
    public boolean toggle(Player player) {
        if (muted.remove(player.getUniqueId())) {
            return true;
        }
        muted.add(player.getUniqueId());
        return false;
    }
}
