package de.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Prüft die Client-Brand. Texturpacks kann der Server technisch nicht auslesen;
 * manche Hack-Clients verraten sich aber über ihre Brand.
 */
public final class ClientCheck implements Check {

    private final AntiCheatPlugin plugin;
    private final AlertManager alerts;
    private final List<String> keywords = new ArrayList<>();
    private boolean enabled;
    private boolean alertNonVanilla;

    public ClientCheck(AntiCheatPlugin plugin, AlertManager alerts) {
        this.plugin = plugin;
        this.alerts = alerts;
    }

    @Override
    public void load(FileConfiguration config) {
        enabled = config.getBoolean("client-check.enabled", true);
        alertNonVanilla = config.getBoolean("client-check.alert-on-non-vanilla", false);
        keywords.clear();
        for (String keyword : config.getStringList("client-check.keywords")) {
            keywords.add(keyword.toLowerCase(Locale.ROOT));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!enabled) {
            return;
        }
        Player player = event.getPlayer();
        // Die Brand wird erst kurz nach dem Beitritt übermittelt
        Bukkit.getScheduler().runTaskLater(plugin, () -> inspect(player), 60L);
    }

    private void inspect(Player player) {
        if (!player.isOnline() || player.hasPermission(AlertManager.PERM_BYPASS)) {
            return;
        }
        String brand = player.getClientBrandName();
        if (brand == null) {
            return;
        }
        String lower = brand.toLowerCase(Locale.ROOT);
        for (String keyword : keywords) {
            if (lower.contains(keyword)) {
                alerts.alert("Client", player, "verdächtige Client-Brand: " + brand, false);
                return;
            }
        }
        if (alertNonVanilla && !lower.equals("vanilla")) {
            alerts.alert("Client", player, "Client-Brand: " + brand, false);
        }
    }
}
