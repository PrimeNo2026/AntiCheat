package de.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Misst die horizontale Geschwindigkeit pro Sekunde (in Server-Ticks, daher lag-sicher)
 * und meldet nach mehreren aufeinanderfolgenden Überschreitungen.
 */
public final class SpeedCheck implements Check {

    private static final class State {
        int windowStartTick;
        double distance;
        int strikes;
        int exemptUntilTick;
        int iceUntilTick;

        void reset(int now) {
            windowStartTick = now;
            distance = 0;
        }
    }

    private static final Set<Material> ICE = Set.of(
            Material.ICE, Material.PACKED_ICE, Material.BLUE_ICE, Material.FROSTED_ICE);

    private final AlertManager alerts;
    private final Map<UUID, State> states = new HashMap<>();
    private boolean enabled;
    private double maxBps;
    private int strikesRequired;

    public SpeedCheck(AlertManager alerts) {
        this.alerts = alerts;
    }

    @Override
    public void load(FileConfiguration config) {
        enabled = config.getBoolean("speed-check.enabled", true);
        maxBps = config.getDouble("speed-check.max-blocks-per-second", 10.0);
        strikesRequired = Math.max(1, config.getInt("speed-check.strikes-required", 3));
    }

    private State state(Player player) {
        return states.computeIfAbsent(player.getUniqueId(), k -> new State());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!enabled || !event.hasChangedPosition()) {
            return;
        }
        Player player = event.getPlayer();
        Location from = event.getFrom();
        Location to = event.getTo();
        int now = Bukkit.getCurrentTick();
        State s = state(player);

        if (!from.getWorld().equals(to.getWorld()) || isExempt(player, s, now)) {
            s.reset(now);
            s.strikes = 0;
            return;
        }

        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double step = Math.sqrt(dx * dx + dz * dz);

        // Sehr große Einzelschritte = Teleport, kein Laufen
        if (step > 8.0) {
            s.exemptUntilTick = now + 40;
            s.reset(now);
            s.strikes = 0;
            return;
        }

        // Auf Eis sind deutlich höhere Geschwindigkeiten normal
        if (ICE.contains(to.getBlock().getRelative(BlockFace.DOWN).getType())) {
            s.iceUntilTick = now + 40;
        }

        // Lange Pause: Fenster neu beginnen
        if (now - s.windowStartTick > 40) {
            s.reset(now);
        }

        s.distance += step;
        int elapsed = now - s.windowStartTick;
        if (elapsed >= 20) {
            double bps = s.distance / (elapsed / 20.0);
            double limit = maxBps * speedMultiplier(player);
            if (now < s.iceUntilTick) {
                s.strikes = 0;
            } else if (bps > limit) {
                s.strikes++;
                if (s.strikes >= strikesRequired) {
                    alerts.alert("Speed", player,
                            String.format(Locale.ROOT, "bewegt sich mit %.1f Blöcken/s (Limit %.1f)", bps, limit),
                            true);
                }
            } else {
                s.strikes = 0;
            }
            s.reset(now);
        }
    }

    private boolean isExempt(Player p, State s, int now) {
        if (now < s.exemptUntilTick) {
            return true;
        }
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) {
            return true;
        }
        if (p.getAllowFlight() || p.isFlying() || p.isGliding() || p.isRiptiding() || p.isInsideVehicle()) {
            // Schwung nach Flug, Elytra, Riptide oder Fahrzeug nicht als Speed werten
            s.exemptUntilTick = now + 40;
            return true;
        }
        return p.hasPermission(AlertManager.PERM_BYPASS);
    }

    private double speedMultiplier(Player p) {
        double m = 1.0;
        PotionEffect speed = p.getPotionEffect(PotionEffectType.SPEED);
        if (speed != null) {
            m += 0.2 * (speed.getAmplifier() + 1);
        }
        return m;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTeleport(PlayerTeleportEvent event) {
        state(event.getPlayer()).exemptUntilTick = Bukkit.getCurrentTick() + 60;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        state(event.getPlayer()).exemptUntilTick = Bukkit.getCurrentTick() + 60;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onVelocity(PlayerVelocityEvent event) {
        state(event.getPlayer()).exemptUntilTick = Bukkit.getCurrentTick() + 40;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        states.remove(event.getPlayer().getUniqueId());
    }
}
