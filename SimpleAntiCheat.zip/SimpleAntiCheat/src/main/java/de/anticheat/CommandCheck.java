package de.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Meldet Admin-Befehle, die von Spielern ohne passende Berechtigung eingegeben werden. */
public final class CommandCheck implements Check {

    private final AlertManager alerts;
    private final Set<String> watched = new HashSet<>();
    private boolean enabled;

    public CommandCheck(AlertManager alerts) {
        this.alerts = alerts;
    }

    @Override
    public void load(FileConfiguration config) {
        enabled = config.getBoolean("command-check.enabled", true);
        watched.clear();
        for (String name : config.getStringList("command-check.watched-commands")) {
            watched.add(name.toLowerCase(Locale.ROOT).replaceFirst("^/", ""));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!enabled) {
            return;
        }
        String raw = event.getMessage().trim();
        if (raw.length() < 2) {
            return;
        }
        String label = raw.substring(1).stripLeading().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        int colon = label.indexOf(':');
        if (colon >= 0) {
            label = label.substring(colon + 1);
        }
        if (!watched.contains(label)) {
            return;
        }

        Player player = event.getPlayer();
        if (player.hasPermission(AlertManager.PERM_BYPASS)) {
            return;
        }
        // Hat der Spieler die Berechtigung für den Befehl, ist es kein Verstoß
        Command command = Bukkit.getCommandMap().getCommand(label);
        if (command != null && command.testPermissionSilent(player)) {
            return;
        }

        String shown = raw.length() > 100 ? raw.substring(0, 100) + "..." : raw;
        alerts.alert("Admin-Befehl", player, "ohne Berechtigung: " + shown, true);
    }
}
