package de.anticheat;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.Listener;

/** Ein einzelner Check, dessen Einstellungen aus der config.yml geladen werden. */
public interface Check extends Listener {
    void load(FileConfiguration config);
}
