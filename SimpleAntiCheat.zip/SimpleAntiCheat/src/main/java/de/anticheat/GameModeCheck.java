package de.anticheat;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerGameModeChangeEvent;

/** Meldet jeden Gamemode-Wechsel. */
public final class GameModeCheck implements Check {

    private final AlertManager alerts;
    private boolean enabled;
    private boolean ignoreStaff;

    public GameModeCheck(AlertManager alerts) {
        this.alerts = alerts;
    }

    @Override
    public void load(FileConfiguration config) {
        enabled = config.getBoolean("gamemode-check.enabled", true);
        ignoreStaff = config.getBoolean("gamemode-check.ignore-staff", false);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onGameMode(PlayerGameModeChangeEvent event) {
        if (!enabled) {
            return;
        }
        // Automatische Wechsel (Beitritt mit Standard-Gamemode, Hardcore-Tod) sind kein Verstoß.
        // Dabei ist der Spieler evtl. noch nicht vollständig online, daher vor jedem Spieler-Zugriff beenden.
        String cause = event.getCause().name();
        if (cause.equals("DEFAULT_GAMEMODE") || cause.equals("HARDCORE_DEATH")) {
            return;
        }
        Player player = event.getPlayer();
        if (player.hasPermission(AlertManager.PERM_BYPASS)
                || (ignoreStaff && player.hasPermission(AlertManager.PERM_ALERTS))) {
            return;
        }
        alerts.alert("Gamemode", player,
                player.getGameMode().name() + " -> " + event.getNewGameMode().name()
                        + " (" + cause + ")",
                false);
    }
}
