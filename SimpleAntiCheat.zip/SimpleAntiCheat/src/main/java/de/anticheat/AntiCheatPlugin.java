package de.anticheat;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class AntiCheatPlugin extends JavaPlugin {

    private AlertManager alerts;
    private final List<Check> checks = new ArrayList<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        alerts = new AlertManager(this);

        checks.add(new SpeedCheck(alerts));
        checks.add(new ResourceCheck(this, alerts));
        checks.add(new GameModeCheck(alerts));
        checks.add(new CommandCheck(alerts));
        checks.add(new ClientCheck(this, alerts));

        for (Check check : checks) {
            getServer().getPluginManager().registerEvents(check, this);
        }
        loadAll();
        getLogger().info("SimpleAntiCheat aktiviert.");
    }

    private void loadAll() {
        alerts.load(getConfig());
        for (Check check : checks) {
            check.load(getConfig());
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(Component.text("Benutzung: /" + label + " <reload|alerts>", NamedTextColor.GRAY));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                reloadConfig();
                loadAll();
                sender.sendMessage(Component.text("[AntiCheat] Konfiguration neu geladen.", NamedTextColor.GREEN));
            }
            case "alerts" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Component.text("Nur ingame benutzbar.", NamedTextColor.RED));
                    return true;
                }
                boolean on = alerts.toggle(player);
                sender.sendMessage(Component.text(
                        "[AntiCheat] Meldungen " + (on ? "eingeschaltet." : "ausgeschaltet."),
                        on ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
            }
            default -> sender.sendMessage(Component.text("Unbekannt. Benutzung: /" + label + " <reload|alerts>",
                    NamedTextColor.RED));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return List.of("reload", "alerts").stream().filter(s -> s.startsWith(prefix)).toList();
        }
        return List.of();
    }
}
