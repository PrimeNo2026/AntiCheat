# SimpleAntiCheat (Paper 26.x)

Meldet verdächtige Aktivitäten an alle Admins (Permission `anticheat.alerts`, Standard: OPs) und in die Konsole.

| Check | Beschreibung |
|---|---|
| Speed | Horizontale Geschwindigkeit pro Sekunde, Speed-Tränke werden eingerechnet |
| Ressourcen | Zu viele Diamanten/Antiker Schrott/Smaragde/Gold in kurzer Zeit |
| Gamemode | Jeder Gamemode-Wechsel |
| Admin-Befehle | Befehle wie /op, /gamemode, /give ohne Berechtigung |
| Client | Verdächtige Client-Brand (Texturpacks sind für Server nicht auslesbar!) |

Befehle: `/anticheat reload`, `/anticheat alerts` (Meldungen an/aus). Alias: `/ac`.
Permissions: `anticheat.admin`, `anticheat.alerts`, `anticheat.bypass`.
Alle Grenzwerte stehen in `plugins/SimpleAntiCheat/config.yml`.

## Jar über GitHub bauen (ohne lokale Tools)

1. Neues Repository auf GitHub erstellen.
2. `Add file` -> `Upload files`: die ZIP-Datei `SimpleAntiCheat.zip` hochladen und committen (muss nicht entpackt werden).
3. `Add file` -> `Create new file`, Name exakt `.github/workflows/build.yml`, Inhalt der mitgelieferten `build.yml` einfügen, committen.
4. Reiter `Actions`: Der Build läuft automatisch. Danach liegt die `.jar` unter `Releases`.

Benötigt Java 25 auf dem Server (Paper 26.1+).
