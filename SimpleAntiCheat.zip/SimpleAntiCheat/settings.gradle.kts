rootProject.name = "SimpleAntiCheat"
